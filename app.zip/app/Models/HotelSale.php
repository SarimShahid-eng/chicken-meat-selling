<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class HotelSale extends Model
{
    protected $fillable = [
        'voucher_no',
        'customer_id',
        'date',
        'total_weight',
        'total_amount',
    ];

    protected $appends = ['formatted_date'];

    protected function casts(): array
    {
        return [
            'date' => 'date',
        ];
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(HotelSaleItem::class);
    }

    public function customerPayment(): HasOne
    {
        return $this->hasOne(CustomerPayment::class, 'sale_id', 'id');
    }

    protected function formattedDate(): Attribute
    {
        return Attribute::make(
            get: fn (mixed $value, array $attributes) => $this->created_at?->format('d-m-Y'),
        );
    }
}
