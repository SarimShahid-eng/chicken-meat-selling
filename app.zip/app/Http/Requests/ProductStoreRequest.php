<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProductStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'update_id' => 'nullable|exists:products,id',
            'name' => [
                'required',
                'string',
                // Checks uniqueness in 'products' table, 'name' column, but ignores this product's ID
                Rule::unique('products', 'name')->ignore($this->update_id),
            ],
            'description' => 'nullable|string',
            'soldCreateWise' => 'required|in:0,1',
        ];
    }
}
